mot=input("Entrez un nom : ")
n=int(input("Nombre de répétitions ? : "))
print(f"Voici {n} repetitions :",end="")
for i in range (n):
    print(mot,end=" ")
