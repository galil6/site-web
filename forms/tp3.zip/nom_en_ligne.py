nom=input("Entrez un nom: ")
for lettre in nom : 
    print(lettre)