n=int(input("Entrez un nombre entier n: "))
for i in range(1,n+1):
    if i < n:
        print(i,end=",")
    else:
        print(n)