mot= input("Entrez un mot : ")
print("Repetitions :",end=" ")
for i in range(3):
    print(mot,end=" ")