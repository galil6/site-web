n= int(input("Entrez un nombre : "))
print(f"table de multiplication de {n}")
for i in range(10):
    print(f"{n} . {i} = {n*i}")