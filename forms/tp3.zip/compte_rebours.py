n=int(input("Entrez un nombre : "))
for i in range(n,21):
    if n<20:
        print(i,end=",")
    else :
        print(f"Il faut rentrer un nombre plus petit que 20")
        