def hello(nom="inconnu(e)"):
    """
    Affiche Hello [nom]!
    """
    print(f"Hello {nom}!")

hello()