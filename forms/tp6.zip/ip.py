from random import randint
def adresses_ip(classe:str="A") -> str:
    """
    Retourne une adresse ipv4 aléatoirement de classe classe
    """
    a = randint(0,127)
    b = randint(0,255) 
    c = randint(0,255)
    d = randint(0,255)
    if classe == "B":
        a = randint(128,192)
    elif classe == "C":
        a = randint(192,223)
    elif classe == "D":
        a = randint(224,239)
    elif classe == "E":
        a = randint(240,255)   
    return f"{a}.{b}.{c}.{d}"

def classe(adresse:str) -> str:
    """
    Retourne la classe de l'adresse ipv4 adresse
    """
    a = int(adresse.split(".")[0])
    classe = ""
    if a < 128:
        classe = "A"
    elif a < 192:
        classe = "B"
    elif a < 224:
        classe = "C"
    elif a < 240:
        classe = "D"
    else:       
        classe = "E" 
    return classe
    

if __name__ == "__main__":
    adr = adresses_ip("A")
    print(f"{adr} est de classe {classe(adr)}")