from random import randint

def liste_utilisateur(n=5):
    """
    Retourne une liste de n entiers saisis par l'utilisateur
    Par défaut n vaut 5
    """
    l = []
    for _ in range(n):
        l.append(int(input("Veuillez saisir un entier svp : ")))
    return l

def liste_aleatoire(n=5, bornemin=0, bornemax=100):
    """
    Retourne une liste de n entiers aléatoires compris entre bornemin et bornemax
    Par défaut : n vaut 5, bornemin vaut 0 et bornemax vaut 100
    """
    l = []
    for _ in range(n):
        l.append(randint(bornemin,bornemax))
    return l
if __name__ == "__main__":
    l1=liste_utilisateur(4)
    print(l1)
    l2=liste_aleatoire(4)
    print(l2)
