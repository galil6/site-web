from creation_liste2 import liste_aleatoire

print(liste_aleatoire(5,1,20))

