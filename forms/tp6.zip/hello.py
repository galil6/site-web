def hello(nom):
    """
    Affiche Hello [nom]!
    """
    print(f"Hello {nom}!")

# Instruction de test
hello("Bob")
