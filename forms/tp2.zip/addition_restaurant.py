montant= int(input("quelle est le montant total de l'addition au restaurant ?"))
nombre = int(input("quelle est le  nombre de convives ?"))
cout= montant/nombre
print(f"Le montant par personne est de {cout} euro(s)")