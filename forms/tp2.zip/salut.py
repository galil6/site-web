nom = input("quelle est ton nom?")
prenom = input("quelle est ton prenom?")
print(f" Salut {nom} {prenom} comment ca va?")
