nom= input("quelle est votre nom ? ")
age=int(input("quelle est votre age ?"))
nouvel = age +1 
print(f"{nom} à votre prochain anniversaire, vous aurez {nouvel}")