poids=float(input("quelle est votre poids en kg?"))
taille=float(input("quelle est votre taille en m?"))
IMC= poids/taille**2
print(f"Votre imc est {IMC:.2f}")
