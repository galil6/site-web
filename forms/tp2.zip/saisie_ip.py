ip= int(input("Veuillez svp entrer une adresse ipv4 :"))
ip_list = ip.split(".")
len(ip_list)=4
if ip_list(0).isdigit(0) and 0<=int(ip_list)<=255:
        and ip_list(1).isdigit and 0<=int(ip_list)<=255
        and ip_list(2).isdigit and 0<=int(ip_list)<=255
        and ip_list(3).isdigit and 0<=int(ip_list)<=255
        and ip_list(4).isdigit and 0<=int(ip_list)<=255
print
