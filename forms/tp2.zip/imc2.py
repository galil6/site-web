poids=float(input("quelle est votre poids en kg?"))
taille=float(input("quelle est votre taille en m?"))
IMC= poids/taille**2
if IMC < 18.5:
    print(f"Votre imc est {IMC:.2f} vous etes dans une position de point maigreur")
elif IMC < 25 : 
    print(f"votre imc est {IMC:.2f} vous dans une situation de point normal")
elif IMC < 30 :
    print(f"votre imc est {IMC:.2f} vous etes dans une situation de point surpoids")
else:
    print(f"votre imc est {IMC:.2f} vous etes dans une situation de obesité")