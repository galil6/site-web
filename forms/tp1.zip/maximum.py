nombre1 = input("Nombre 1 : ")
nombre2 = input("Nombre 2: ")

M=max(nombre1,nombre2)
print(f"le nombre maximal est {M}")
