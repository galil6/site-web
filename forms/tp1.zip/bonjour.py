prenom = input("Quel est ton prénom ? ")
print("Bonjour " + prenom)

