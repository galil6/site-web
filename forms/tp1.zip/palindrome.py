mot= input("donne moi un mot ")
if mot[::-1]== mot :
    print(f"{mot}est un palindrome")
          