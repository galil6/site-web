#!/usr/bin/env python3

import string
from random import choice, choices, shuffle
import argparse

parser = argparse.ArgumentParser(description="Displays a robust password")
parser.add_argument("length", type=int, nargs="?", default=10, help="password length requested")
args = parser.parse_args()

MINLENGTH = 10

""" Génère un mdp de longueur l
    avec au moins :
    - 1 caractère ascii minuscule
    - 1 caractère ascii majuscule
    - 1 chiffre
    - 1 caractère de ponctuation
"""
if args.length < MINLENGTH:
    print("La longueur demandée est trop petite."+\
            f" Le mot de passe généré sera de longueur {MINLENGTH}.")
    args.length = MINLENGTH
car = string.ascii_letters + string.digits + string.punctuation
passwd_l = list(choice(string.ascii_lowercase) +\
    choice(string.ascii_uppercase) +\
    choice(string.digits) +\
    choice(string.punctuation))
passwd_l += choices(car,k=args.length-4)
shuffle(passwd_l)
print("".join(passwd_l))
