#!/usr/bin/env python3
import requests

proxies = {
  "http": "http://cache-etu.univ-artois.fr:3128",
  "https": "http://cache-etu.univ-artois.fr:3128",
}

r = requests.get("https://rt-bethune.univ-artois.fr/", proxies=proxies)

# Encodage de la réponse pour lire sous un système Linux
r.encoding = "utf-8"

# Affichage du contenu de la page
print(f"La page contient : {r.text}")
