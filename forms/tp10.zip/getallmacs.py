#!/usr/bin/env python3

import re
import argparse

parser = argparse.ArgumentParser(
    description="output in macs.txt the mac addresses present in a text file")
parser.add_argument("file", help="text file containing mac addresses")
args = parser.parse_args()

with open(args.file) as f:
    text = f.read()

motif = re.compile(r"([0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2}")
matches = motif.finditer(text)

with open("macs.txt","w") as f:
    for match in matches:
        f.write(match.group()+"\n")