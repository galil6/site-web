#!/usr/bin/env python3

import requests
import re
import argparse

parser = argparse.ArgumentParser(description="Displays the emails found in a URL")
parser.add_argument("url", help="url")
args = parser.parse_args()

r = requests.get(args.url)
r.encoding = 'utf-8'
motif = re.compile(r"[\.\w-]+@[\w-]+\.\w+")
matches = motif.finditer(r.text)
for match in matches:
    print(match.group())
