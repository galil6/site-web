# #v1
# liste=[]
# liste.append(input("Nom de votre machine: "))
# liste.append(int(input("RAM (Go) : ")))
# liste.append(float(input("CPU (GHz) : ")))
# print("La liste contient : ", liste)

#v2
machine=[0,1,2,]
machine[0]=input("Nom de votre machine: ")
machine[1]=int(input("RAM (Go) : "))
machine[2]=float(input("CPU (GHz) : "))
print("La liste contient : ",machine)