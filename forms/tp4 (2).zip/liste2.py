liste= list(range(1,1001))
print(liste)