liste = [1, 4, 5, 67, 23.2, -12, 0]
print("Premier élément =",liste[0])
print("Dernier élément =" ,liste[-1])
print("3 premiers éléments = ",liste[:3])
print("Nombre d'éléments =",len(liste))
print("Min =",min(liste))
print("Max =",max(liste))
print("Somme = ",sum(liste))
liste.sort()
print("Liste ordonnée de manière croissante  = " ,liste)
liste. sort(reverse = True)
print("Liste ordonnée de manière décroissante  =",liste)

