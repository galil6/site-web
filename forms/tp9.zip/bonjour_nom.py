#!/usr/bin/env python3
nom = input("Quel est votre nom ? ")
print(f"Bonjour {nom}")