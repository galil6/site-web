#!/usr/bin/env python3
import argparse

parser = argparse.ArgumentParser(description="Displays Bonjour followed by a name")
parser.add_argument("name", help="a name to be displayed")

args = parser.parse_args()

print(f"Bonjour {args.name}")