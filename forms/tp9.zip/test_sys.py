#!/usr/bin/env python3
import sys
if len(sys.argv) < 2:
    print("Usage: ./bonjour2 [nom]")
else:
    nom = sys.argv[1]
    print(f"Bonjour {nom}")